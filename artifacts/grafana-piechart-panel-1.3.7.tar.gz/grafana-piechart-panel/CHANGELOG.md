# Change Log

## [1.3.7] - 2019-07-22

- conversion to typescript
- fixes several bugs
- fixes 6.3 compatibility
- use toolkit for building
- fix for issue #154

